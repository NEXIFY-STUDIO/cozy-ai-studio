# Moja super kópia
Toto je tvoja kópia z Cozy Labu ✨
ID: bp_ms6lh5tu_ssghls
Kedy: 2026-07-29T21:26:25.218Z
Kocky na plátne: 2
## Ako ju vrátiť späť (3 kroky)
1. Otvor Cozy Lab → „Kópia magie“
2. Rozbaľ tento ZIP
3. Nahraj súbor blueprint.json
Hotovo — magia je späť.
Len tvoje projekty. Nekopíruj cudzie weby.