import React from "react";

export default function App() {
  return (
    <main className="min-h-screen bg-[#F4F1EA] text-[#1C1D21] font-sans">
      <header className="border-b border-black/10 px-6 py-4 flex items-center justify-between">
        <h1 className="font-serif text-2xl font-bold tracking-tight">Aurora</h1>
        <nav className="flex gap-6 text-sm text-black/60">
          <a href="#features">Features</a>
          <a href="#pricing">Pricing</a>
          <button className="rounded-lg bg-[#D96B43] px-4 py-2 text-white font-medium">
            Get started
          </button>
        </nav>
      </header>
      <section className="mx-auto max-w-3xl px-6 py-24 text-center">
        <p className="mb-4 text-sm font-medium tracking-widest text-[#D96B43] uppercase">
          Warm Brutalism
        </p>
        <h2 className="font-serif text-5xl font-bold leading-tight mb-6">
          Design that feels handmade
        </h2>
        <p className="text-lg text-black/60 mb-10 max-w-xl mx-auto">
          A starter landing page generated inside Cozy AI Studio. Edit with AI agents and watch the preview update live.
        </p>
        <div className="flex justify-center gap-3">
          <button className="rounded-xl bg-[#D96B43] px-6 py-3 text-white font-medium shadow-[4px_4px_0_#1C1D21]">
            Start building
          </button>
          <button className="rounded-xl border-2 border-[#1C1D21] px-6 py-3 font-medium">
            View demo
          </button>
        </div>
      </section>
    </main>
  );
}
